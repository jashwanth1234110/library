import React from "react";
import Banner from "./Banner";
import "../../Assets/css/home.css";
import Lists from "./Lists";
import AllMember from "./AllMember";
import DummyData from "./DummyData";

const HomePage = ({ user }) => {
  return (
    <div className="home-top">
      <div className="home-header">
        <div className="home-header-overlay">
          <h1>Welcome to GRIET Central Library</h1>
          <p>Gokaraju Rangaraju Institute of Engineering and Technology</p>
        </div>
      </div>
      
      <div className="home-content">
        <Banner user={user} />
        <DummyData />
        
        <div className="home-main-content">
          {user.name != "jashwanthh" ? <Lists user={user} /> : <AllMember user={user} />}
        </div>
      </div>
    </div>
  );
};

export default HomePage;
