import React from "react";

const DummyData = () => {
  return (
    <div className="stats-container">
      <h2 className="stats-heading">Library Statistics</h2>
      
      <div className="stats-grid">
        <div className="stats-card">
          <div className="stats-icon">
            <i className="fas fa-book"></i>
          </div>
          <div className="stats-content">
            <div className="stats-value">42,500+</div>
            <div className="stats-label">Books</div>
          </div>
        </div>
        
        <div className="stats-card">
          <div className="stats-icon">
            <i className="fas fa-users"></i>
          </div>
          <div className="stats-content">
            <div className="stats-value">8,200+</div>
            <div className="stats-label">Members</div>
          </div>
        </div>
        
        <div className="stats-card">
          <div className="stats-icon">
            <i className="fas fa-newspaper"></i>
          </div>
          <div className="stats-content">
            <div className="stats-value">125+</div>
            <div className="stats-label">Journals</div>
          </div>
        </div>
        
        <div className="stats-card">
          <div className="stats-icon">
            <i className="fas fa-globe"></i>
          </div>
          <div className="stats-content">
            <div className="stats-value">15+</div>
            <div className="stats-label">E-Resources</div>
          </div>
        </div>
      </div>
      
      <div className="stats-note">
        <p>The library is open from <strong>8:00 AM to 8:00 PM</strong> on working days and <strong>10:00 AM to 3:00 PM</strong> on holidays.</p>
      </div>
    </div>
  );
};

export default DummyData;
