import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Lists = ({ user }) => {
  const [data, setData] = useState([]);
  const [selectedBooks, setSelectedBooks] = useState([]);
  const navigate = useNavigate();

  const [filter, setfilter] = useState({
    search: "-",
  });

  const handleInputs = (e) => {
    setfilter({ ...filter, [e.target.name]: e.target.value });
  };

  const addToCart = async () => {
    if (selectedBooks.length === 0) {
      toast.warn("Please select at least one book to proceed", {
        position: "top-center",
        autoClose: 2000,
      });
      return;
    }

    const books = selectedBooks;
    const username = user.username;
    const send = { books: books, username: username };

    try {
      const response = await axios.post(`http://localhost:5000/addToCart`, send);
      toast.success("Books added to cart successfully!", {
        position: "top-center",
        autoClose: 2000,
      });
      setTimeout(() => {
        navigate("/cart");
      }, 1500);
    } catch (error) {
      console.error("Error adding to cart:", error);
      const errorMessage = error.response?.data?.msg || "Failed to add books to cart";
      toast.error(errorMessage, {
        position: "top-center",
        autoClose: 3000,
      });
    }
  };

  const fetchData = async () => {
    let search = filter.search;
    if (search.length == 0) {
      search = "-";
    }

    try {
      const response = await axios.get(`http://localhost:5000/search/${search}`);
      setData(response.data.books || []);
    } catch (error) {
      console.error("Error fetching books:", error);
      toast.error("Failed to fetch books", {
        position: "top-center",
        autoClose: 3000,
      });
    }
  };

  useEffect(() => {
    let delayTimer;
    const handleFilterChange = () => {
      clearTimeout(delayTimer);
      delayTimer = setTimeout(fetchData, 1500);
    };

    handleFilterChange();

    return () => {
      clearTimeout(delayTimer);
    };
  }, [filter]);

  const handleBookClick = (id) => {
    navigate(`/book/${id}`);
  };

  const handleCheckboxChange = (e, id) => {
    if (e.target.checked) {
      setSelectedBooks((prevSelectedBooks) => [...prevSelectedBooks, id]);
    } else {
      setSelectedBooks((prevSelectedBooks) =>
        prevSelectedBooks.filter((bookId) => bookId !== id)
      );
    }
  };

  //variables
  const [currentPage, setCurrentPage] = useState(1);
  const recordPerPage = 10;
  const lastIndex = currentPage * recordPerPage;
  const firstIndex = lastIndex - recordPerPage;
  const record = data.slice(firstIndex, lastIndex);
  const npage = Math.ceil(data.length / recordPerPage);
  const number = [...Array(npage + 1).keys()].slice(1);

  const nextPage = () => {
    if (currentPage != npage) {
      setCurrentPage(currentPage + 1);
    }
  };
  const prevPage = () => {
    if (currentPage != 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div>
      <ToastContainer />
      {data.length > 0 ? (
        <>
          <div style={{ padding: "2rem" }}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <div style={{ fontFamily: "poppins", fontSize: "2rem" }}>
                Books
              </div>
              <div className="search-container">
                <input
                  type="text"
                  name="search"
                  className="search-input"
                  placeholder="Search books..."
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            <table className="table">
              <thead style={{ backgroundColor: "#3d5a80", color: "white" }}>
                <th style={{ width: "5rem", textAlign: "left" }}>#</th>
                <th style={{ width: "15rem", textAlign: "left" }}>Name</th>
                <th style={{ width: "15rem", textAlign: "left" }}>Publisher</th>
                <th style={{ width: "15rem", textAlign: "left" }}>Genre</th>
                <th style={{ width: "15rem", textAlign: "left" }}>
                  Add To Cart
                </th>
              </thead>
              <tbody>
                {record.map((d, i) => (
                  <tr key={i}>
                    <td>{(currentPage - 1) * 10 + i + 1}</td>
                    <td
                      style={{ cursor: "pointer", padding: "0.5rem" }}
                      onClick={() => handleBookClick(d.Title)}
                    >
                      {d.Title}
                    </td>
                    <td style={{ padding: "0.5rem" }}>{d.Author}</td>
                    <td style={{ padding: "0.5rem" }}>{d.Genre}</td>
                    <td style={{ padding: "0.5rem" }}>
                      <input
                        type="checkbox"
                        onChange={(e) => handleCheckboxChange(e, d.ISBN)}
                        checked={selectedBooks.includes(d.ISBN)}
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div
            style={{
              textAlign: "center",
              marginBlockStart: "2rem",
              display: "flex",
              flexDirection: "row",
              justifyContent: "center",
            }}
          >
            <div
              className="land-button lists-button"
              style={{ margin: "0 1rem", padding: "0", cursor: "pointer" }}
              onClick={prevPage}
            >
              <a
                className="landing-button-hover"
                style={{ width: "5rem", margin: "10px" }}
              >
                <span>PREV</span>
              </a>
            </div>

            <div style={{ paddingBlockStart: "1rem" }}>{currentPage}</div>
            <div
              className="land-button"
              style={{ margin: "0 1rem", padding: "0", cursor: "pointer" }}
              onClick={nextPage}
            >
              <a
                className="landing-button-hover"
                style={{ width: "5rem", margin: "10px" }}
              >
                <span>NEXT</span>
              </a>
            </div>
          </div>
          <div
            style={{
              marginLeft: "45rem",
              marginBlockEnd: "2rem",
            }}
          >
            <div
              className="land-button"
              style={{ cursor: "pointer" }}
              onClick={addToCart}
            >
              <a
                className="landing-button-hover"
                style={{
                  width: "20rem",
                }}
              >
                <span>PROCEED TO CHECKOUT</span>
              </a>
            </div>
            <div style={{ marginLeft: "1.5rem" }}>
              Save Selected Items To Cart And Proceed To Checkout
            </div>
          </div>
        </>
      ) : (
        <div className="loaders book">
          <figure className="page"></figure>
          <figure className="page"></figure>
          <figure className="page"></figure>
        </div>
      )}
    </div>
  );
};

export default Lists;
