import React from "react";

const Banner = ({ user }) => {
  return (
    <div className="home-banner">
      <div className="banner-main">
        <h1>
          {user.name != "jashwanthh" ? (
            <>GRIET Library Collection</>
          ) : (
            <>Library Members Directory</>
          )}
        </h1>
        <p className="banner-subtitle">
          {user.name != "jashwanthh" ? (
            <>Explore our vast collection of academic resources and literature</>
          ) : (
            <>Manage active members and their borrowing activities</>
          )}
        </p>
      </div>
      <div className="banner-decoration">
        <div className="banner-line"></div>
      </div>
    </div>
  );
};

export default Banner;
