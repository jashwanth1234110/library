import React, { useState, useEffect } from "react";
import "../Assets/css/landing.css";

const LandingPage = () => {
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoading(false);
    }, 3500);

    return () => clearTimeout(timer);
  }, []);

  const handleImageLoad = () => {
    setIsLoading(false);
  };

  return (
    <div className="land-top">
      <div className="land-inner-top">
        <div className={`land-banner-image ${isLoading ? "loading" : ""}`}>
          {isLoading && (
            <div className="loaders book">
              <figure className="page"></figure>
              <figure className="page"></figure>
              <figure className="page"></figure>
            </div>
          )}
          <img
            className={`vert-move ${isLoading ? "hidden" : ""}`}
            src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQQN_94Gv0cy6pF2B_Et8hd6IyRonfB4Vz6d5zL065mhEiKvotKCsmyfO7S&s=10"
            alt="GRIET Library"
            srcSet=""
            onLoad={handleImageLoad}
          />
        </div>
        <div className="land-banner-slogan">
          <div className="land-banner-slogan-inner">
            <div className="land-logo">GRIET Library</div>
            <div className="land-subtitle">Gokaraju Rangaraju Institute of Engineering and Technology</div>
            <div className="land-motto">Discover, Learn, Excel</div>
            <div className="land-description">
              Empowering students with knowledge resources for academic excellence and innovation
            </div>
            <div className="land-button">
              <a className="landing-button-hover" href="/home">
                <span>EXPLORE</span>
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
