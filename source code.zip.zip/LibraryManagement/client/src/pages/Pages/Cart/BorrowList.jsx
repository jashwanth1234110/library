import axios from "axios";
import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import "../../Assets/css/borrowers.css";

const BorrowList = () => {
  const [data, setData] = useState([]);
  const [selectedBooks, setSelectedBooks] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const navigate = useNavigate();

  const addToCart = async () => {
    if (selectedBooks.length === 0) {
      alert("Please select at least one book to proceed");
      return;
    }
    // Implementation for saving changes
  };

  const fetchData = async () => {
    try {
      const response = await axios.get("http://localhost:5000/borrowedBooks");
      setData(response.data);
    } catch (error) {
      console.error("Error fetching borrowed books:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  function formatDate(dateStr) {
    const currentDate = new Date();
    const date = new Date(dateStr);
    const options = { day: "numeric", month: "long", year: "numeric" };

    const timeDiff = Math.abs(currentDate.getTime() - date.getTime());
    const diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));

    if (diffDays > 8) {
      return `Due by ${diffDays} days`;
    } else {
      const formattedDate = date.toLocaleDateString("en-US", options);
      return formattedDate;
    }
  }

  const handleCheckboxChange = (e, id) => {
    if (e.target.checked) {
      setSelectedBooks((prevSelectedBooks) => [...prevSelectedBooks, id]);
    } else {
      setSelectedBooks((prevSelectedBooks) =>
        prevSelectedBooks.filter((bookId) => bookId !== id)
      );
    }
  };

  // Pagination variables
  const [currentPage, setCurrentPage] = useState(1);
  const recordPerPage = 10;
  const lastIndex = currentPage * recordPerPage;
  const firstIndex = lastIndex - recordPerPage;
  const record = data.slice(firstIndex, lastIndex);
  const npage = Math.ceil(data.length / recordPerPage);
  const number = [...Array(npage + 1).keys()].slice(1);

  const nextPage = () => {
    if (currentPage !== npage) {
      setCurrentPage(currentPage + 1);
    }
  };

  const prevPage = () => {
    if (currentPage !== 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  return (
    <div className="borrowers-container">
      <div className="borrowers-header">
        <h1 className="borrowers-title">Borrowed Books</h1>
      </div>

      {isLoading ? (
        <div className="loading-container">
          <div className="loading-spinner"></div>
        </div>
      ) : data.length > 0 ? (
        <>
          <table className="borrowers-table">
            <thead>
              <tr>
                <th>#</th>
                <th>Borrower</th>
                <th>Title</th>
                <th>Author</th>
                <th>Due Date</th>
                <th>Select</th>
              </tr>
            </thead>
            <tbody>
              {record.map((d, i) => (
                <tr key={i}>
                  <td>{(currentPage - 1) * 10 + i + 1}</td>
                  <td>{d.borrower}</td>
                  <td>{d.title}</td>
                  <td>{d.author}</td>
                  <td>{formatDate(d.takenDate)}</td>
                  <td>
                    <input
                      type="checkbox"
                      className="borrower-checkbox"
                      onChange={(e) => handleCheckboxChange(e, d.isbn)}
                      checked={selectedBooks.includes(d.isbn)}
                    />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>

          <div className="borrowers-pagination">
            <button
              className="pagination-button"
              onClick={prevPage}
              disabled={currentPage === 1}
            >
              PREV
            </button>
            <div className="page-number">{currentPage}</div>
            <button
              className="pagination-button"
              onClick={nextPage}
              disabled={currentPage === npage}
            >
              NEXT
            </button>
          </div>

          <button className="save-changes-button" onClick={addToCart}>
            SAVE CHANGES
          </button>
          <div className="save-changes-text">
            Save Returned Status of Borrower
          </div>
        </>
      ) : (
        <div className="loading-container">
          <h2>No borrowed books found</h2>
        </div>
      )}
    </div>
  );
};

export default BorrowList;
