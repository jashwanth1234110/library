// // import axios from "axios";
// // import React, { useEffect, useState } from "react";
// // import "../../Assets/css/cart.css";
// // import { ToastContainer, toast } from "react-toastify";
// // import "react-toastify/dist/ReactToastify.css";

// // const Cart = ({ user }) => {
// //   const [data, setData] = useState([null]);
// //   const [isLoading, setIsLoading] = useState(true); // Add isLoading state

// //   const fetchData = async () => {
// //     try {
// //       const response = await axios.get(
// //         `http://localhost:5000/booksInCart/${user.username}`
// //       );
// //       setData(response.data.books);
// //       console.log(data);
// //       setIsLoading(false); // Set isLoading to false when data is fetched
// //     } catch (error) {
// //       console.error(error);
// //     }
// //   };

// //   // const proceedCheckout = async () => {
// //   //   const username = user.username;
// //   //   const send = { username: username };
// //   //   try {
// //   //     const response = await axios.post(`http://localhost:5000/checkout`, send);
// //   //     console.log(response);
// //   //     toast.success("Checkout successful!", {
// //   //       position: "top-center",
// //   //       autoClose: 2000,
// //   //     });
// //   //     setTimeout(() => {
// //   //       window.location.href = "/home";
// //   //     }, 2000);
// //   //   } catch (error) {
// //   //     console.error("Checkout error:", error);
// //   //     const errorMessage = error.response?.data?.msg || "Something went wrong during checkout";
// //   //     toast.error(errorMessage, {
// //   //       position: "top-center",
// //   //       autoClose: 3000,
// //   //     });
// //   //   }
// //   // };
// //   const proceedCheckout = async () => {
// //     const payload = {
// //       username: user.username,
// //       cart: data, // Assuming 'data' holds the list of books
// //     };
  
// //     try {
// //       const response = await axios.post(
// //         "http://localhost:5000/checkout",
// //         payload,
// //         {
// //           headers: {
// //             "Content-Type": "application/json",
// //           },
// //         }
// //       );
// //       console.log(response);
// //       toast.success("Checkout successful!", {
// //         position: "top-center",
// //         autoClose: 2000,
// //       });
// //       setTimeout(() => {
// //         window.location.href = "/home";
// //       }, 2000);
// //     } catch (error) {
// //       console.error("Checkout error:", error);
// //       const errorMessage =
// //         error.response?.data?.msg || "Something went wrong during checkout";
// //       toast.error(errorMessage, {
// //         position: "top-center",
// //         autoClose: 3000,
// //       });
// //     }
// //   };
  
// //   useEffect(() => {
// //     fetchData();
// //   }, []);

// //   if (data == null) {
// //     return <>NULL H RE BABA</>;
// //   } else
// //     return (
// //       <div style={{ paddingBlockStart: "4rem" }}>
// //         <ToastContainer />
// //         <div style={{ display: "flex" }}>
// //           <div style={{ flex: "5" }}>
// //             {isLoading ? ( // Render loading state when isLoading is true
// //               <div>
// //                 <img
// //                   style={{
// //                     width: "10rem",
// //                     marginInlineStart: "10.5em",
// //                     marginBlockStart: "9rem",
// //                   }}
// //                   src="https://raw.githubusercontent.com/AnuragRoshan/images/2da16323d0b50258ee4a9f8ffe0ec96bf73ed0b9/undraw_happy_music_g6wc.svg"
// //                   alt=""
// //                   srcset=""
// //                 />
// //                 <div
// //                   style={{
// //                     textAlign: "center",
// //                     fontFamily: "poppins",
// //                     fontSize: "2rem",
// //                   }}
// //                 >
// //                   Cart is empty <br /> Add Some Books
// //                 </div>
// //               </div>
// //             ) : data.length === 0 ? (
// //               <></>
// //             ) : (
// //               <>
// //                 <div>
// //                   <div style={{ padding: "2rem" }}>
// //                     <div style={{ display: "flex" }}>
// //                       <div style={{ fontFamily: "poppins", fontSize: "3rem" }}>
// //                         CART
// //                       </div>
// //                       <div className="cart-button" onClick={proceedCheckout}>
// //                         Checkout
// //                       </div>
// //                     </div>
// //                     {data.map((d, i) => (
// //                       <div
// //                         key={i}
// //                         style={{
// //                           display: "flex",
// //                           width: "100%",
// //                           border: "1px solid transparent",
// //                           backgroundColor: "white",
// //                           marginBlockEnd: "1rem",
// //                         }}
// //                       >
// //                         <div>
// //                           <img
// //                             src="https://covers.openlibrary.org/b/isbn/1933988746-L.jpg"
// //                             alt=""
// //                             srcset=""
// //                             style={{
// //                               width: "5rem",
// //                               height: "6rem",
// //                               marginTop: "0rem",
// //                               padding: "0.4rem 1rem",
// //                             }}
// //                           />
// //                         </div>
// //                         <div
// //                           style={{
// //                             fontFamily: "poppins",
// //                             padding: "0.4rem 1rem",
// //                             fontSize: "0.9rem",
// //                           }}
// //                         >
// //                           <div>Title : {d.Title}</div>
// //                           <div>Author : {d.Author}</div>
// //                           <div>Publisher : {d.Publisher}</div>
// //                         </div>
// //                       </div>
// //                     ))}
// //                   </div>
// //                 </div>
// //               </>
// //             )}
// //           </div>
// //           <div style={{ flex: "8", backgroundColor: "white" }}>
// //             <img
// //               style={{ height: "86vh" }}
// //               src="https://raw.githubusercontent.com/AnuragRoshan/images/8b58d063ae66f90faefec23c75fe787161fc66ca/undraw_empty_cart_co35.svg"
// //               alt=""
// //               srcset=""
// //             />
// //           </div>
// //         </div>
// //       </div>
// //     );
// // };

// // export default Cart;

// import axios from "axios";
// import React, { useEffect, useState, useCallback } from "react";
// import { useLocation } from "react-router-dom";
// import "../../Assets/css/cart.css";
// import { ToastContainer, toast } from "react-toastify";
// import "react-toastify/dist/ReactToastify.css";

// const Cart = () => {
//   const location = useLocation();
//   const user = location.state?.user;

//   const [data, setData] = useState([]);
//   const [isLoading, setIsLoading] = useState(true);

//   const fetchData = useCallback(async () => {
//     try {
//       const response = await axios.get(
//         `http://localhost:5000/booksInCart/${user.username}`
//       );
//       setData(response.data.books || []);
//       setIsLoading(false);
//     } catch (error) {
//       console.error("Error fetching cart data:", error);
//       setIsLoading(false);
//     }
//   }, [user.username]);

//   const proceedCheckout = async () => {
//     const payload = {
//       username: user.username,
//       cart: data,
//     };

//     try {
//       const response = await axios.post(
//         "http://localhost:5000/checkout",
//         payload,
//         {
//           headers: {
//             "Content-Type": "application/json",
//           },
//         }
//       );
//       console.log(response);
//       toast.success("Checkout successful!", {
//         position: "top-center",
//         autoClose: 2000,
//       });
//       setTimeout(() => {
//         window.location.href = "/home";
//       }, 2000);
//     } catch (error) {
//       console.error("Checkout error:", error);
//       const errorMessage =
//         error.response?.data?.msg || "Something went wrong during checkout";
//       toast.error(errorMessage, {
//         position: "top-center",
//         autoClose: 3000,
//       });
//     }
//   };

//   useEffect(() => {
//     if (!user || !user.username) {
//       toast.error("User not found. Please login.", {
//         position: "top-center",
//         autoClose: 3000,
//       });
//       return;
//     }
//     fetchData();
//   }, [fetchData, user]);

//   if (!user || !user.username) {
//     return (
//       <div style={{ padding: "2rem", textAlign: "center" }}>
//         User not found. Please login.
//       </div>
//     );
//   }

//   return (
//     <div style={{ paddingBlockStart: "4rem" }}>
//       <ToastContainer />
//       <div style={{ display: "flex" }}>
//         <div style={{ flex: "5" }}>
//           {isLoading ? (
//             <div>Loading...</div>
//           ) : data.length === 0 ? (
//             <div>
//               <img
//                 style={{
//                   width: "10rem",
//                   marginInlineStart: "10.5em",
//                   marginBlockStart: "9rem",
//                 }}
//                 src="https://raw.githubusercontent.com/AnuragRoshan/images/2da16323d0b50258ee4a9f8ffe0ec96bf73ed0b9/undraw_happy_music_g6wc.svg"
//                 alt="Empty Cart"
//               />
//               <div
//                 style={{
//                   textAlign: "center",
//                   fontFamily: "poppins",
//                   fontSize: "2rem",
//                 }}
//               >
//                 Cart is empty <br /> Add Some Books
//               </div>
//             </div>
//           ) : (
//             <>
//               <div style={{ padding: "2rem" }}>
//                 <div
//                   style={{
//                     display: "flex",
//                     justifyContent: "space-between",
//                     alignItems: "center",
//                   }}
//                 >
//                   <div
//                     style={{ fontFamily: "poppins", fontSize: "3rem" }}
//                   >
//                     CART
//                   </div>
//                   <div className="cart-button" onClick={proceedCheckout}>
//                     Checkout
//                   </div>
//                 </div>
//                 {data.map((d, i) => (
//                   <div
//                     key={i}
//                     style={{
//                       display: "flex",
//                       width: "100%",
//                       border: "1px solid transparent",
//                       backgroundColor: "white",
//                       marginBlockEnd: "1rem",
//                     }}
//                   >
//                     <div>
//                       <img
//                         src="https://covers.openlibrary.org/b/isbn/1933988746-L.jpg"
//                         alt="Book Cover"
//                         style={{
//                           width: "5rem",
//                           height: "6rem",
//                           marginTop: "0rem",
//                           padding: "0.4rem 1rem",
//                         }}
//                       />
//                     </div>
//                     <div
//                       style={{
//                         fontFamily: "poppins",
//                         padding: "0.4rem 1rem",
//                         fontSize: "0.9rem",
//                       }}
//                     >
//                       <div>Title : {d.Title}</div>
//                       <div>Author : {d.Author}</div>
//                       <div>Publisher : {d.Publisher}</div>
//                     </div>
//                   </div>
//                 ))}
//               </div>
//             </>
//           )}
//         </div>
//         <div style={{ flex: "8", backgroundColor: "white" }}>
//           <img
//             style={{ height: "86vh" }}
//             src="https://raw.githubusercontent.com/AnuragRoshan/images/8b58d063ae66f90faefec23c75fe787161fc66ca/undraw_empty_cart_co35.svg"
//             alt="Cart Illustration"
//           />
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Cart;
import axios from "axios";
import React, { useEffect, useState, useCallback } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import "../../Assets/css/cart.css";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Cart = () => {
  const location = useLocation();
  const navigate = useNavigate();

  // Retrieve user from location.state or localStorage
  const [user, setUser] = useState(() => {
    const stateUser = location.state?.user;
    if (stateUser) {
      localStorage.setItem("user", JSON.stringify(stateUser));
      return stateUser;
    }
    const storedUser = localStorage.getItem("user");
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const [data, setData] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  const fetchData = useCallback(async () => {
    if (!user || !user.username) return;
    try {
      const response = await axios.get(
        `http://localhost:5000/booksInCart/${user.username}`
      );
      setData(response.data.books || []);
    } catch (error) {
      console.error("Error fetching cart data:", error);
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  const proceedCheckout = async () => {
    if (!user || !user.username) {
      toast.error("User not found. Please login.", {
        position: "top-center",
        autoClose: 3000,
      });
      return;
    }

    const payload = {
      username: user.username,
      cart: data,
    };

    try {
      const response = await axios.post(
        "http://localhost:5000/checkout",
        payload,
        {
          headers: {
            "Content-Type": "application/json",
          },
        }
      );
      console.log(response);
      toast.success("Checkout successful!", {
        position: "top-center",
        autoClose: 2000,
      });
      setTimeout(() => {
        navigate("/home");
      }, 2000);
    } catch (error) {
      console.error("Checkout error:", error);
      const errorMessage =
        error.response?.data?.msg || "Something went wrong during checkout";
      toast.error(errorMessage, {
        position: "top-center",
        autoClose: 3000,
      });
    }
  };

  useEffect(() => {
    if (!user || !user.username) {
      toast.error("User not found. Please login.", {
        position: "top-center",
        autoClose: 3000,
      });
      return;
    }
    fetchData();
  }, [fetchData, user]);

  if (!user || !user.username) {
    return (
      <div style={{ padding: "2rem", textAlign: "center" }}>
        User not found. Please login.
      </div>
    );
  }

  return (
    <div style={{ paddingBlockStart: "4rem" }}>
      <ToastContainer />
      <div style={{ display: "flex" }}>
        <div style={{ flex: "5" }}>
          {isLoading ? (
            <div>Loading...</div>
          ) : data.length === 0 ? (
            <div>
              <img
                style={{
                  width: "10rem",
                  marginInlineStart: "10.5em",
                  marginBlockStart: "9rem",
                }}
                src="https://raw.githubusercontent.com/AnuragRoshan/images/2da16323d0b50258ee4a9f8ffe0ec96bf73ed0b9/undraw_happy_music_g6wc.svg"
                alt="Empty Cart"
              />
              <div
                style={{
                  textAlign: "center",
                  fontFamily: "poppins",
                  fontSize: "2rem",
                }}
              >
                Cart is empty <br /> Add Some Books
              </div>
            </div>
          ) : (
            <>
              <div style={{ padding: "2rem" }}>
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                  }}
                >
                  <div style={{ fontFamily: "poppins", fontSize: "3rem" }}>
                    CART
                  </div>
                  <div className="cart-button" onClick={proceedCheckout}>
                    Checkout
                  </div>
                </div>
                {data.map((d, i) => (
                  <div
                    key={i}
                    style={{
                      display: "flex",
                      width: "100%",
                      border: "1px solid transparent",
                      backgroundColor: "white",
                      marginBlockEnd: "1rem",
                    }}
                  >
                    <div>
                      <img
                        src="https://covers.openlibrary.org/b/isbn/1933988746-L.jpg"
                        alt="Book Cover"
                        style={{
                          width: "5rem",
                          height: "6rem",
                          marginTop: "0rem",
                          padding: "0.4rem 1rem",
                        }}
                      />
                    </div>
                    <div
                      style={{
                        fontFamily: "poppins",
                        padding: "0.4rem 1rem",
                        fontSize: "0.9rem",
                      }}
                    >
                      <div>Title : {d.Title}</div>
                      <div>Author : {d.Author}</div>
                      <div>Publisher : {d.Publisher}</div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
        </div>
        <div style={{ flex: "8", backgroundColor: "white" }}>
          <img
            style={{ height: "86vh" }}
            src="https://raw.githubusercontent.com/AnuragRoshan/images/8b58d063ae66f90faefec23c75fe787161fc66ca/undraw_empty_cart_co35.svg"
            alt="Cart Illustration"
          />
        </div>
      </div>
    </div>
  );
};

export default Cart;

