import React from "react";

const BorrowBanner = () => {
  return (
    <div className="home-banner" style={{ fontFamily: "poppins" }}>
      <></>
    </div>
  );
};

export default BorrowBanner;
