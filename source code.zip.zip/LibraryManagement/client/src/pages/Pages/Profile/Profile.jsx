import React, { useState } from "react";
import "../../Assets/css/profile.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Profile = ({ user }) => {
  const dateStr = user.createdAt;
  const date = new Date(dateStr);
  const options = { day: "numeric", month: "long", year: "numeric" };
  const formattedDate = date.toLocaleDateString("en-US", options);

  const [data, setData] = useState({
    name: user.name,
    username: user.username,
    phone: user.phone,
    address: user.address,
    uniqueId: user.uniqueId,
  });

  const handleInputs = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const submitForm = async () => {
    try {
      const response = await axios.post(`http://localhost:5000/updateUser`, data);
      const message = response.data.msg;
      const status = response.status;

      if (status === 200) {
        toast.success(message, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
        });
        setTimeout(() => {
          window.location.href = "/profile";
        }, 1500);
      } else if (status === 202) {
        toast.warn(message, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
        });
      }
    } catch (error) {
      console.error("Error updating profile:", error);
    }
  };

  return (
    <div className="profile-container">
      <div className="profile-grid">
        {/* Profile Card */}
        <div className="profile-card">
          <div className="profile-header">
            <div className="profile-avatar">
              <img
                src="https://i.ibb.co/sv5Zf5CM/rohith.jpg"
                alt="Profile Avatar"
                className="avatar-image"
              />
            </div>
            <div className="profile-info">
              <h2 className="profile-name">{user.name}</h2>
              <p className="profile-id">UID: {user.uniqueId}</p>
              <p className="profile-date">Member since {formattedDate}</p>
            </div>
          </div>
          
          <div className="profile-stats">
            <div className="stat-item">
              <span className="stat-value">{user.cart.length}</span>
              <span className="stat-label">Books in Cart</span>
            </div>
            <div className="stat-item">
              <span className="stat-value">{user.borrowedBooks?.length || 0}</span>
              <span className="stat-label">Borrowed Books</span>
            </div>
          </div>
        </div>

        {/* Edit Profile Section */}
        <div className="edit-profile-section">
          <div className="section-header">
            <h2>Edit Profile</h2>
            <p>Update your personal information</p>
          </div>
          
          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <div className="input-group">
                <i className="fas fa-user"></i>
                <input
                  type="text"
                  id="name"
                  name="name"
                  value={data.name}
                  onChange={handleInputs}
                  placeholder="Enter your full name"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="username">Email</label>
              <div className="input-group">
                <i className="fas fa-envelope"></i>
                <input
                  type="email"
                  id="username"
                  name="username"
                  value={data.username}
                  onChange={handleInputs}
                  placeholder="Enter your email"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="phone">Phone Number</label>
              <div className="input-group">
                <i className="fas fa-phone"></i>
                <input
                  type="tel"
                  id="phone"
                  name="phone"
                  value={data.phone}
                  onChange={handleInputs}
                  placeholder="Enter your phone number"
                />
              </div>
            </div>

            <div className="form-group">
              <label htmlFor="address">Address</label>
              <div className="input-group">
                <i className="fas fa-map-marker-alt"></i>
                <input
                  type="text"
                  id="address"
                  name="address"
                  value={data.address}
                  onChange={handleInputs}
                  placeholder="Enter your address"
                />
              </div>
            </div>
          </div>

          <button className="update-button" onClick={submitForm}>
            Update Profile
          </button>
        </div>

        {/* Feedback Section */}
        <div className="feedback-section">
          <div className="section-header">
            <h2>Feedback & Suggestions</h2>
            <p>Help us improve our services</p>
          </div>
          
          <div className="feedback-form">
            <textarea
              placeholder="Share your thoughts, suggestions, or report any issues..."
              rows="4"
              className="feedback-input"
            />
            <button className="submit-feedback-button">
              Submit Feedback
            </button>
          </div>
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default Profile;
