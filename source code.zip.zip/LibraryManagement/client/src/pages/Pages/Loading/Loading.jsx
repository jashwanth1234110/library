import React, { useState, useEffect } from 'react';
import '../../Assets/css/loading.css';

const Loading = () => {
  const [tips] = useState([
    "Did you know? Reading for just 6 minutes can reduce stress by 68%",
    "The average person reads about 12 books per year",
    "The first book ever printed was the Gutenberg Bible in 1455",
    "The longest novel ever written has 1,267,069 words",
    "Reading before bed can help you sleep better",
    "The most expensive book ever sold was Leonardo da Vinci's Codex Leicester for $30.8 million",
    "The world's largest library is the Library of Congress with over 170 million items",
    "Reading can improve your memory and concentration",
    "The first book ever written was The Epic of Gilgamesh in 2100 BC",
    "Reading can increase your vocabulary by up to 20%"
  ]);

  const [currentTip, setCurrentTip] = useState(0);
  const [stats] = useState({
    books: 10000,
    users: 5000,
    genres: 25,
    authors: 2000
  });

  useEffect(() => {
    const tipInterval = setInterval(() => {
      setCurrentTip((prev) => (prev + 1) % tips.length);
    }, 5000);

    return () => clearInterval(tipInterval);
  }, [tips.length]);

  return (
    <div className="loading-container">
      <div className="loading-header">
        <h1 className="loading-title">Library Management System</h1>
        <p className="loading-subtitle">Loading your personalized experience...</p>
      </div>

      <div className="loading-content">
        <div className="loading-card">
          <h2 className="loading-card-title">Library Statistics</h2>
          <div className="loading-stats">
            <div className="stat-item">
              <div className="stat-number">{stats.books}</div>
              <div className="stat-label">Books</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">{stats.users}</div>
              <div className="stat-label">Users</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">{stats.genres}</div>
              <div className="stat-label">Genres</div>
            </div>
            <div className="stat-item">
              <div className="stat-number">{stats.authors}</div>
              <div className="stat-label">Authors</div>
            </div>
          </div>
        </div>

        <div className="loading-spinner-container">
          <div className="loading-spinner"></div>
        </div>

        <div className="loading-progress">
          <div className="loading-progress-bar"></div>
        </div>

        <p className="loading-tip">
          {tips[currentTip]}
        </p>
      </div>
    </div>
  );
};

export default Loading; 