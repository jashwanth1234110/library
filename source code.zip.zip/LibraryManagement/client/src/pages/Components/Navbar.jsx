import React, { useState } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import "../Assets/css/navbar.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const Navbar = ({ user }) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [showChat, setShowChat] = useState(false);

  const handleHomeClick = () => navigate("/home");
  const handleRecentlyAddedClick = () => navigate("/profile");

  const handelCart = () => {
    if (user.name != "jashwanthh") {
      navigate("/cart");
    } else {
      navigate("/borrower");
    }
  };

  const handleLogout = async () => {
    try {
      const response = await axios.post(`http://localhost:5000/logout`, null, {
        withCredentials: true,
      });
      const message = response.data.msg;
      const status = response.status;

      if (status === 200) {
        toast.success(`${message}`, {
          position: "top-center",
          autoClose: 2000,
        });
        setTimeout(() => {
          window.location.href = "/";
        }, 1500);
      } else if (status === 202) {
        toast.warn(`${message}`, {
          position: "top-center",
          autoClose: 2000,
        });
      }
    } catch (error) {
      console.error("Logout failed", error);
    }
  };

  const isLinkActive = (path) => location.pathname === path;

  return (
    <div>
      <div className="nav-top">
        <div className="nav-inner-top">
          <div className="nav-logo" onClick={handleHomeClick} style={{ cursor: "pointer", display: "flex", alignItems: "center" }}>
            <span className="logo-text">GRIET</span>
            <span className="logo-divider">|</span>
            <span className="logo-library">Library</span>
          </div>

          <div className="nav-links">
            <div className={`nav-link ${isLinkActive("/home") ? "active" : ""}`} onClick={handleHomeClick}>
              <i className="fas fa-book"></i> Books
            </div>
            <div
              className={`nav-link ${isLinkActive("/borrower") || isLinkActive("/cart") ? "active" : ""}`}
              onClick={handelCart}
            >
              <i className={user.name != "jashwanthh" ? "fas fa-shopping-cart" : "fas fa-users"}></i>
              {user.name != "jashwanthh" ? "Cart" : "Borrowers"}
            </div>
            <div className={`nav-link ${isLinkActive("/profile") ? "active" : ""}`} onClick={handleRecentlyAddedClick}>
              <i className="fas fa-user-circle"></i> Profile
            </div>
            <div className="nav-link" onClick={() => setShowChat(!showChat)}>
              <i className="fas fa-robot"></i>SuggestionBot
            </div>
            <div className="nav-link logout" onClick={handleLogout}>
              <i className="fas fa-sign-out-alt"></i> Logout
            </div>
          </div>

          {user && (
            <div className="user-info">
              <span className="user-type">{user.name != "jashwanthh" ? "Student" : "Administrator"}</span>
              <span className="user-name">{user.name}</span>
            </div>
          )}
        </div>
      </div>

      {showChat && <SuggestionBot onClose={() => setShowChat(false)} />}
      <ToastContainer />
    </div>
  );
};

// ✅ Simple Inline Styles (can move to CSS later)
const SuggestionBotBox = {
  position: "fixed",
  bottom: "80px",
  right: "20px",
  width: "350px",
  height: "450px",
  backgroundColor: "#ffffff",
  boxShadow: "0 8px 16px rgba(0,0,0,0.1)",
  borderRadius: "15px",
  display: "flex",
  flexDirection: "column",
  zIndex: 9999,
  border: "1px solid #e0e0e0",
  overflow: "hidden",
  transition: "all 0.3s ease",
};

const chatHeader = {
  padding: "15px 20px",
  backgroundColor: "#4a90e2",
  color: "white",
  fontWeight: "600",
  display: "flex",
  justifyContent: "space-between",
  alignItems: "center",
  borderTopLeftRadius: "15px",
  borderTopRightRadius: "15px",
  fontSize: "16px",
  boxShadow: "0 2px 4px rgba(0,0,0,0.1)",
};

const closeBtn = {
  background: "none",
  border: "none",
  color: "white",
  fontSize: "24px",
  cursor: "pointer",
  padding: "0",
  width: "30px",
  height: "30px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  borderRadius: "50%",
  transition: "background-color 0.2s ease",
};

const chatBody = {
  flex: 1,
  padding: "20px",
  overflowY: "auto",
  display: "flex",
  flexDirection: "column",
  gap: "12px",
  backgroundColor: "#f8f9fa",
  scrollbarWidth: "thin",
  scrollbarColor: "#c1c1c1 #f8f9fa",
};

const chatMessage = {
  background: "#ffffff",
  padding: "12px 16px",
  borderRadius: "12px",
  maxWidth: "80%",
  boxShadow: "0 2px 4px rgba(0,0,0,0.05)",
  fontSize: "14px",
  lineHeight: "1.4",
  position: "relative",
};

const chatInputBox = {
  display: "flex",
  padding: "15px",
  borderTop: "1px solid #e0e0e0",
  backgroundColor: "#ffffff",
  gap: "10px",
};

const chatInput = {
  flex: 1,
  padding: "12px 15px",
  border: "1px solid #e0e0e0",
  borderRadius: "8px",
  fontSize: "14px",
  outline: "none",
  transition: "border-color 0.2s ease",
  backgroundColor: "#f8f9fa",
};

const sendBtn = {
  padding: "12px 20px",
  backgroundColor: "#4a90e2",
  color: "white",
  border: "none",
  borderRadius: "8px",
  cursor: "pointer",
  fontWeight: "600",
  fontSize: "14px",
  transition: "background-color 0.2s ease",
};

// Add hover effects
const hoverStyles = {
  closeBtn: {
    ...closeBtn,
    "&:hover": {
      backgroundColor: "rgba(255,255,255,0.2)",
    },
  },
  chatInput: {
    ...chatInput,
    "&:focus": {
      borderColor: "#4a90e2",
      backgroundColor: "#ffffff",
    },
  },
  sendBtn: {
    ...sendBtn,
    "&:hover": {
      backgroundColor: "#357abd",
    },
  },
};

// Update the component to use hover styles
const SuggestionBot = ({ onClose }) => {
  const [message, setMessage] = useState("");
  const [chatLog, setChatLog] = useState([]);

  const sendMessage = async () => {
    if (!message.trim()) return;
    const userMessage = { sender: "user", text: message };
    setChatLog([...chatLog, userMessage]);

    try {
      const res = await axios.post("http://localhost:5000/api/chat", { message });
      const botReply = { sender: "bot", text: res.data.reply };
      setChatLog((prev) => [...prev, botReply]);
    } catch (error) {
      console.error("SuggestionBot error:", error);
    }

    setMessage("");
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      sendMessage();
    }
  };

  return (
    <div style={SuggestionBotBox}>
      <div style={chatHeader}>
        <span>Ask SuggestionBot</span>
        <button onClick={onClose} style={hoverStyles.closeBtn}>×</button>
      </div>
      <div style={chatBody}>
        {chatLog.map((msg, index) => (
          <div 
            key={index} 
            style={{ 
              ...chatMessage, 
              alignSelf: msg.sender === "user" ? "flex-end" : "flex-start",
              backgroundColor: msg.sender === "user" ? "#4a90e2" : "#ffffff",
              color: msg.sender === "user" ? "white" : "#333333",
            }}
          >
            <span style={{ fontWeight: "bold", marginRight: "5px" }}>
              {msg.sender === "user" ? "You" : "Bot"}:
            </span> 
            {msg.text}
          </div>
        ))}
      </div>
      <div style={chatInputBox}>
        <input
          type="text"
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyPress={handleKeyPress}
          placeholder="Ask about Book Suggestions "
          style={hoverStyles.chatInput}
        />
        <button onClick={sendMessage} style={hoverStyles.sendBtn}>Send</button>
      </div>
    </div>
  );
};

export default Navbar;

