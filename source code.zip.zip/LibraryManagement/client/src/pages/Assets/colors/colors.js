const colors = {
    // #3d5a80 // #98c1d9 // #e0fbfc // #ee6c4d //#293241
    lightblue: "#e0fbfc",
    mediumblue: "#98c1d9",
    darkblue: "#3d5a80",
    darkestblue: "#293241",
    textOrange: "#293241"
}

export default colors;