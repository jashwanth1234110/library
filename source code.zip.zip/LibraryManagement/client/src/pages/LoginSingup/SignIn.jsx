import { useState } from "react";
import "../Assets/css/login.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { Navigate, useNavigate } from "react-router-dom";
// import { FaEnvelope, FaLock, FaLockOpen, FaUser } from "react-icons/fa";

const Signin = () => {
  const [user, setUser] = useState({});
  const navigate = useNavigate();

  const handleInputs = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };

  const submitForm = async () => {
    try {
      const response = await axios.post(`http://localhost:5000/login`, user, {
        withCredentials: true,
      });

      const message = response.data.message;
      const status = response.data.status;

      if (status === "200") {
        toast.success(message, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
        });
        window.location.href = "/profile";
      } else if (status === "202") {
        toast.warn(message, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
          theme: "dark",
        });
      } else if (status === "500") {
        toast.error(message, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
          theme: "dark",
        });
      }
    } catch (error) {
      console.error("An error occurred:", error);

      if (error.message === "Network Error") {
        toast.error("Network error. Please check your internet connection.", {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
          theme: "dark",
        });
      }
    }
  };

  const img1 =
    "https://github.com/AnuragRoshan/images/blob/main/Lovepik_com-450098997-Account%20login%20flat%20illustration.png?raw=true";
  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-branding">
          <div className="login-logo">
            <div className="logo-text">GRIET</div>
            <div className="logo-divider">|</div>
            <div className="logo-library">Library</div>
          </div>
          <div className="login-tagline">
            Gokaraju Rangaraju Institute of Engineering and Technology
          </div>
        </div>
        
        <div className="login-form-container">
          <h2>Login to Your Account</h2>
          <p className="login-form-subtitle">Access the GRIET library resources</p>
          
          <div className="login-form">
            <div className="form-group">
              <label htmlFor="username">Email</label>
              <div className="input-group">
                <i className="fas fa-envelope"></i>
                <input
                  type="text"
                  id="username"
                  name="username"
                  className="form-control"
                  placeholder="Enter your email"
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <div className="input-group">
                <i className="fas fa-lock"></i>
                <input
                  type="password"
                  id="password"
                  name="password"
                  className="form-control"
                  placeholder="Enter your password"
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            
            <button
              type="button"
              className="login-button"
              onClick={() => submitForm()}
            >
              Sign In
            </button>
            
            <div className="login-help">
              <div className="login-signup">
                Don't have an account? <a href="/signup">Sign Up</a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="login-image">
          <img
            src="https://i.ibb.co/Vc2z04H7/Chat-GPT-Image-Apr-29-2025-11-42-20-PM.png"
            alt="GRIET Library"
          />
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default Signin;
