import React, { useState } from "react";
import "../Assets/css/login.css";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

const SignUp = () => {
  const [user, setUser] = useState({});

  const handleInputs = (e) => {
    setUser({ ...user, [e.target.name]: e.target.value });
  };
  
  const submitForm = async () => {
    try {
      const response = await axios.post(`http://localhost:5000/register`, user);
      
      const message = response.data.msg;
      const status = response.status;

      if (status === 200) {
        toast.success(`${message}`, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
        });
        setTimeout(() => {
          window.location.href = "/signin";
        }, 1500);
      } else if (status === 202) {
        toast.warn(`${message}`, {
          position: "top-center",
          autoClose: 2000,
          pauseOnHover: false,
          pauseOnFocusLoss: false,
          draggable: true,
          textAlign: "center",
        });
      }
    } catch (error) {
      toast.error("An error occurred during registration", {
        position: "top-center",
        autoClose: 2000,
        pauseOnHover: false,
        pauseOnFocusLoss: false,
        draggable: true,
        textAlign: "center",
      });
    }
  };

  return (
    <div className="login-container">
      <div className="login-card">
        <div className="login-branding">
          <div className="login-logo">
            <div className="logo-text">GRIET</div>
            <div className="logo-divider">|</div>
            <div className="logo-library">Library</div>
          </div>
          <div className="login-tagline">
            Gokaraju Rangaraju Institute of Engineering and Technology
          </div>
        </div>
        
        <div className="login-form-container">
          <h2>Create Your Account</h2>
          <p className="login-form-subtitle">Join the GRIET library community</p>
          
          <div className="login-form">
            <div className="form-group">
              <label htmlFor="name">Full Name</label>
              <div className="input-group">
                <i className="fas fa-user"></i>
                <input
                  type="text"
                  id="name"
                  name="name"
                  className="form-control"
                  placeholder="Enter your full name"
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="username">Email</label>
              <div className="input-group">
                <i className="fas fa-envelope"></i>
                <input
                  type="text"
                  id="username"
                  name="username"
                  className="form-control"
                  placeholder="Enter your email address"
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="phone">Phone Number</label>
              <div className="input-group">
                <i className="fas fa-phone"></i>
                <input
                  type="text"
                  id="phone"
                  name="phone"
                  className="form-control"
                  placeholder="Enter your 10-digit phone number"
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            
            <div className="form-group">
              <label htmlFor="password">Password</label>
              <div className="input-group">
                <i className="fas fa-lock"></i>
                <input
                  type="password"
                  id="password"
                  name="password"
                  className="form-control"
                  placeholder="Create a secure password"
                  onChange={(e) => handleInputs(e)}
                />
              </div>
            </div>
            
            <button
              type="button"
              className="login-button"
              onClick={() => submitForm()}
            >
              Create Account
            </button>
            
            <div className="login-help">
              <div className="login-signup">
                Already have an account? <a href="/signin">Sign In</a>
              </div>
            </div>
          </div>
        </div>
        
        <div className="login-image">
          <img
            src="https://st5.depositphotos.com/20923550/70484/v/450/depositphotos_704846914-stock-illustration-boy-glasses-standing-front-bookshelf.jpg"
            alt="GRIET Library"
          />
        </div>
      </div>
      <ToastContainer />
    </div>
  );
};

export default SignUp;
