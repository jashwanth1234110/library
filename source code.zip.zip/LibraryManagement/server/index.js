// const express = require("express")
// const cors = require("cors");
// const passport = require("passport");
// const cookieParser = require("cookie-parser");
// // const bcrypt = require("bcryptjs");
// const session = require("express-session");
// const bodyParser = require("body-parser");
// const morgan = require("morgan");
// const app = express();
// const dotenv = require("dotenv")
// const routes = require("./api/routes/index")
// const router = require("express").Router();
// dotenv.config();


// app.use(morgan("dev"));


// //database connection
// require("./db_connection");


// // Middleware
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(
//     cors({
//         origin: "http://localhost:3000", // <-- location of the react app were connecting to
//         credentials: true,
//     })
// );
// app.use(
//     session({
//         secret: "secretcode",
//         resave: true,
//         saveUninitialized: true,
//         cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000, prioroty: "High" }
//     })
// );
// app.use(cookieParser(process.env.SECRET));
// app.use(passport.initialize());
// app.use(passport.session());
// require("./config/passportConfig")(passport);


// //Middleware End

// //Route

// app.use(routes);




// const PORT = process.env.PORT || 5000;
// app.listen(PORT, () => {
//     console.log("Server Is Connected to Port " + PORT);
// })
// const express = require("express");
// const cors = require("cors");
// const passport = require("passport");
// const cookieParser = require("cookie-parser");
// const session = require("express-session");
// const bodyParser = require("body-parser");
// const morgan = require("morgan");
// const dotenv = require("dotenv");
// const routes = require("./api/routes/index");
// const { GoogleGenerativeAI } = require("@google/generative-ai");

// // Load env variables
// dotenv.config();

// const app = express();
// const PORT = process.env.PORT || 5000;

// // Gemini API setup
// const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
// const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

// let hasGreeted = false;
// let chatHistory = [
//   {
//     role: "user",
//     parts: [
//       "You are a chatbot for a website focused on Indian heritage and culture. " +
//       "Only answer questions related to India’s traditions, history, architecture, festivals, art, and this website. " +
//       "If the user asks anything outside this scope, say: 'I’m here to help with Indian heritage and this website. I can’t answer that.'"
//     ],
//   },
// ];

// // Middleware
// app.use(morgan("dev"));
// app.use(bodyParser.json());
// app.use(bodyParser.urlencoded({ extended: true }));
// app.use(
//   cors({
//     origin: "http://localhost:3000", // frontend origin
//     credentials: true,
//   })
// );
// app.use(
//   session({
//     secret: "secretcode",
//     resave: true,
//     saveUninitialized: true,
//     cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 },
//   })
// );
// app.use(cookieParser(process.env.SECRET));
// app.use(passport.initialize());
// app.use(passport.session());
// require("./config/passportConfig")(passport);

// // Database connection
// require("./db_connection");

// // Main Routes
// app.use(routes);

// // Gemini Chat Route
// app.post("/api/chat", async (req, res) => {
//   const userInput = req.body.message;

//   if (!hasGreeted) {
//     hasGreeted = true;
//     return res.json({
//       reply: "Hey! Do you have any questions about India’s heritage, culture, or our website?",
//     });
//   }

//   try {
//     chatHistory.push({ role: "user", parts: [userInput] });

//     const result = await model.generateContent({
//       contents: chatHistory,
//     });

//     const reply = result.response.text();

//     chatHistory.push({ role: "model", parts: [reply] });

//     res.json({ reply });
//   } catch (err) {
//     console.error("Gemini error:", err);
//     res.status(500).json({ reply: "Sorry, something went wrong." });
//   }
// });

// // Start server
// app.listen(PORT, () => {
//   console.log(`Server is running at http://localhost:${PORT}`);
// });
const express = require("express");
const cors = require("cors");
const passport = require("passport");
const cookieParser = require("cookie-parser");
const session = require("express-session");
const bodyParser = require("body-parser");
const morgan = require("morgan");
const dotenv = require("dotenv");
const routes = require("./api/routes/index");
const { GoogleGenerativeAI } = require("@google/generative-ai");

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Gemini API setup
const genAI = new GoogleGenerativeAI(process.env.GEMINI_API_KEY);
const model = genAI.getGenerativeModel({ model: "gemini-1.5-flash" });

let hasGreeted = false;
let chatHistory = [
  {
    role: "user",
    parts: [
      {
        text:
          "You are a chatbot for a website focused on book suggestions. " +
          "Only answer questions related to books and this website. " +
          "If the user asks anything outside this scope, say: 'I’m here to help with books and this website. I can’t answer that.'"
      }
    ],
  },
];

// Middleware
app.use(morgan("dev"));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(
  cors({
    origin: "http://localhost:3000",
    credentials: true,
  })
);
app.use(
  session({
    secret: "secretcode",
    resave: true,
    saveUninitialized: true,
    cookie: { secure: false, maxAge: 24 * 60 * 60 * 1000 },
  })
);
app.use(cookieParser(process.env.SECRET));
app.use(passport.initialize());
app.use(passport.session());
require("./config/passportConfig")(passport);

// DB Connection
require("./db_connection");

// API Routes
app.use(routes);

// ✅ Gemini Chat Endpoint (fixed formatting)
app.post("/api/chat", async (req, res) => {
  const userInput = req.body.message;

  if (!hasGreeted) {
    hasGreeted = true;
    return res.json({
      reply: "do you want book suggestion",
    });
  }

  try {
    // Push user's input with proper structure
    chatHistory.push({ role: "user", parts: [{ text: userInput }] });

    // Format all history properly for Gemini
    const result = await model.generateContent({
      contents: chatHistory.map(entry => ({
        role: entry.role,
        parts: entry.parts.map(p => (typeof p === "string" ? { text: p } : p)),
      })),
    });

    const reply = result.response.text();
    chatHistory.push({ role: "model", parts: [{ text: reply }] });

    res.json({ reply });
  } catch (err) {
    console.error("Gemini error:", err);
    res.status(500).json({ reply: "Sorry, something went wrong." });
  }
});

app.listen(PORT, () => {
  console.log(`Server is running at http://localhost:${PORT}`);
});
